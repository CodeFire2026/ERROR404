// Ejercicios 72 Convertir a may�sculas y min�sculas
Proceso Ejercicio72
    Definir tex Como Caracter;
    
    Leer tex;
    
    Escribir Mayusculas(tex);
    Escribir Minusculas(tex);
FinProceso