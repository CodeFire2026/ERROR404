// Ejercicio 100: Ejemplo de par�metro por valor, sumar 10.
Funcion sumarDiez(valor)
	valor <- valor + 10;
	Escribir "Dentro de la funci�n: ", valor;
FinFuncion

Algoritmo Ejercicio100
	Definir num Como Entero;
	
	Escribir "Ingrese un n�mero: ";
	Leer num;
	
	sumarDiez(num);
	
	Escribir "Fuera de la funci�n: ", num;
FinAlgoritmo