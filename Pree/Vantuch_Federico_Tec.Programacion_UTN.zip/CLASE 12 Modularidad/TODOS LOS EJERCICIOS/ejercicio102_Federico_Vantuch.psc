//  Ejercicio 102: Pedir un nombre y desplegarlo rodeado por la misma cantidad de asteriscos que los caracteres que tiene. La cantidad de asteriscos debe ser la misma que los caracteres en el nombre incluido espacios (Pseudoc�digo) .
Proceso Ejercicio102
    Definir nombre Como Cadena;
    Definir i, tamano Como Entero; // Cambiamos "longitud" por "tamano"
    
    Escribir "Ingrese su nombre: ";
    Leer nombre;
    
    tamano <- Longitud(nombre); // Aqu� usamos la funci�n del sistema
    
    // L�nea de asteriscos superior
    Para i <- 1 Hasta tamano Hacer
        Escribir Sin Saltar "*";
    FinPara
    
    Escribir ""; // Salto de l�nea
    Escribir nombre;
    
    // L�nea de asteriscos inferior
    Para i <- 1 Hasta tamano Hacer
        Escribir Sin Saltar "*";
    FinPara
    
    Escribir ""; // Salto de l�nea final
FinProceso