SubProceso CalcularPotencia
    Definir base, exponente, resultado Como Real;
    Escribir "Ingrese la base:";
    Leer base;
    Escribir "Ingrese el exponente:";
    Leer exponente;
    resultado <- base ^ exponente;
    Escribir "El resultado es: ", resultado;
    Escribir "Presione Enter para continuar...";
    Esperar Tecla;
FinSubProceso

SubProceso CalcularRaiz
    Definir num, resultado Como Real;
    Escribir "Ingrese el n�mero para calcular ra�z cuadrada:";
    Leer num;
    Si num >= 0 Entonces
        resultado <- raiz(num);
        Escribir "La ra�z cuadrada es: ", resultado;
    Sino
        Escribir "Error: No existe ra�z cuadrada de n�meros negativos en reales.";
    FinSi
    Escribir "Presione Enter para continuar...";
    Esperar Tecla;
FinSubProceso

Proceso  Ejercicio103
    Definir opcion Como Entero;
    
    Repetir
        Borrar Pantalla;
        Escribir "=== MEN� DE OPERACIONES ===";
        Escribir "1. Potenciaci�n";
        Escribir "2. Ra�z Cuadrada";
        Escribir "3. Terminar";
        Escribir "Seleccione una opci�n: ";
        Leer opcion;
        
        Segun opcion Hacer
            1:
                CalcularPotencia();
            2:
                CalcularRaiz();
            3:
                Escribir "Programa finalizado. �Adi�s!";
            De Otro Modo:
                Escribir "Opci�n no v�lida. Intente de nuevo.";
                Esperar 2 Segundos;
        FinSegun
        
    Hasta Que opcion = 3
FinProceso
