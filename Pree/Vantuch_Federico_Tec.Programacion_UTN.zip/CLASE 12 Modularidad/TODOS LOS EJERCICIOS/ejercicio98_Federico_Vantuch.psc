//	Ejercicio 98: Funci�n para sumar dos n�meros.
Funcion resultado <- sumar(a, b)
	definir resultado Como Entero;
	resultado <- a + b;
FinFuncion

Algoritmo Ejercicio98
	Definir num1, num2, res Como Entero;
	
	Escribir "Ingrese un n�mero: ";
	Leer num1;
	Escribir "Ingrese otro n�mero: ";
	Leer num2;
	
	res <- sumar(num1, num2);
	
	Escribir "La suma es: ", res;
FinAlgoritmo