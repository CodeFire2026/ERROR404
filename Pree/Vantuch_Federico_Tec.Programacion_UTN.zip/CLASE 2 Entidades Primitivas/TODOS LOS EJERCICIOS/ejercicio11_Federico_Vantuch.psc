//?	Ejercicio 11: Funciones Matem�ticas. Uso de azar(num) para generar un n�mero del 0 al 49 .

Proceso ejercicio11
		Definir num Como Entero;
		
		num <- azar(50);
		
		Escribir "Numero aleatorio: ", num;
FinProceso
