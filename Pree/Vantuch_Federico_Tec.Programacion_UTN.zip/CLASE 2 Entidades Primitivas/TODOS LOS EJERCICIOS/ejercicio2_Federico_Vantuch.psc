//Ejercicio 2: Pr�ctica de asignaci�n de variables utilizando Camel Case .
Proceso Ejerrcicios_Practicos
		Definir nombreUsuario Como Cadena;
		Definir edadUsuario Como Entero;
		
		nombreUsuario <- "Fede";
		edadUsuario <- 21;
		
		Escribir "Nombre: ", nombreUsuario;
		Escribir "Edad: ", edadUsuario;
	
FinProceso
