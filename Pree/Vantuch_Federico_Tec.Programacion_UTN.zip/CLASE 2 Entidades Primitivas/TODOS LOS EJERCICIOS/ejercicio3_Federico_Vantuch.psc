//?	Ejercicio 3: Pr�ctica de variables integrando todos los casos (Camel, Pascal, Snake, Kebab) .
Proceso Ejercicio3
		// Camel Case
		Definir nombreUsuario Como Cadena;
		nombreUsuario <- "Fede";
		Escribir "Camel Case - Nombre: ", nombreUsuario;
		
		// Pascal Case (simulado, PSeInt no diferencia may�sculas en variables pero lo usamos igual)
		Definir EdadUsuario Como Entero;
		EdadUsuario <- 21;
		Escribir "Pascal Case - Edad: ", EdadUsuario;
		
		// Snake Case
		Definir ciudad_usuario Como Cadena;
		ciudad_usuario <- "San Rafael";
		Escribir "Snake Case - Ciudad: ", ciudad_usuario;
		
		// Kebab Case (NO es v�lido en PSeInt, se simula con texto)
		Definir ejemploKebab Como Cadena;
		ejemploKebab <- "usuario-activo";
		Escribir "Kebab Case (simulado): ", ejemploKebab;
FinProceso
