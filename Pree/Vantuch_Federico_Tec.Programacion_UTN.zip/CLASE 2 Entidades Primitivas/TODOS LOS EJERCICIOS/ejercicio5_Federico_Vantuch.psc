//?	Ejercicio 5: Operaci�n de asignaci�n simple: pedir un valor entero y mostrarlo

Proceso ejercicio5
		Definir num Como Entero;
		
		Escribir "Ingrese un numero:";
		Leer num;
		
		Escribir "El numero ingresado es: ", num;
FinProceso
