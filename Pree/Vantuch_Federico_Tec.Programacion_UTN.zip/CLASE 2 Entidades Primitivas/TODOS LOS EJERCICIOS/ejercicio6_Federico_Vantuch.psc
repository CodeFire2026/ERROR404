//	Ejercicio 6: Prioridad de operadores aritm�ticos: 

Proceso ejercicio6
		Definir resultado Como Real;
		
		resultado <- 5 + 3 * 2;
		
		Escribir "Resultado: ", resultado;
FinProceso
