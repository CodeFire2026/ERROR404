// Ejercicio 7: Suma aritm�tica simple (10+8).
Proceso ejercicio7
		Definir resultado Como Entero;
		
		resultado <- 10 + 8;
		
		Escribir "Resultado: ", resultado;
FinProceso
