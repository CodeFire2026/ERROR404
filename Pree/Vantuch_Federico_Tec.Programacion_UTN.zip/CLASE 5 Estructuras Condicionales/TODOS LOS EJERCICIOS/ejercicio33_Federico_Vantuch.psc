//?	Ejercicio 33:Hacer un programa que tenga un men� con las siguientes opciones(Diagrama N-S):
//Opci�n 1: Elevar un n�mero a una potencia X 
//Opci�n 2: Sacar la ra�z cuadrada de un n�mero 
//Opci�n 3: Salir 
Proceso ejercicio33
		Definir opcion Como Entero;
		Definir num, potencia, resultado Como Real;
		
		Escribir "MENU:";
		Escribir "1. Elevar un numero a una potencia";
		Escribir "2. Raiz cuadrada de un numero";
		Escribir "3. Salir";
		
		Escribir "Seleccione una opcion:";
		Leer opcion;
		
		Segun opcion Hacer
			
			1:
				Escribir "Ingrese numero:";
				Leer num;
				Escribir "Ingrese potencia:";
				Leer potencia;
				
				resultado <- num ^ potencia;
				
				Escribir "Resultado: ", resultado;
				
			2:
				Escribir "Ingrese numero:";
				Leer num;
				
				Si num >= 0 Entonces
					resultado <- rc(num);
					Escribir "Raiz cuadrada: ", resultado;
				SiNo
					Escribir "No se puede calcular raiz de numero negativo";
				FinSi
				
			3:
				Escribir "Saliendo del programa...";
				
			De Otro Modo:
				Escribir "Opcion invalida";
				
		FinSegun
FinProceso
