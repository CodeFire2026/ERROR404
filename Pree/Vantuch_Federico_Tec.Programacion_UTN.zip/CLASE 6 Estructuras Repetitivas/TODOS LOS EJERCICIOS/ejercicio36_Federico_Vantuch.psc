// Ejercicio 36: Imprimir en pantalla los n�meros del 1 al 10 (Ciclo Repetir).
Proceso ejercicio36
		Definir i Como Entero;
		i <- 1;
		
		Repetir
			Escribir i;
			i <- i + 1;
		Hasta Que i > 10;
FinProceso
