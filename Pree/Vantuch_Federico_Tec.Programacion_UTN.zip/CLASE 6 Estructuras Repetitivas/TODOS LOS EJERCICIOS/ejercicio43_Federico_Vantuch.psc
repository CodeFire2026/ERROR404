// Ejercicio 43: Calcular la calificaci�n promedio y la calificaci�n m�s baja de un grupo de 10 alumnos (Pseudoc�digo, Ciclo Para) .
Proceso ejercicio43
		Definir nota, suma, menor Como Real;
		Definir i Como Entero;
		
		suma <- 0;
		
		Para i <- 1 Hasta 10 Hacer
			Leer nota;
			suma <- suma + nota;
			
			Si i = 1 O nota < menor Entonces
				menor <- nota;
			FinSi
		FinPara
		
		Escribir "Promedio: ", suma / 10;
		Escribir "Nota mas baja: ", menor;
FinProceso
